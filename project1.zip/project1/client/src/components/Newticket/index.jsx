import React, { useEffect, useState } from 'react';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import axios from 'axios';
import jwtDecode from 'jwt-decode';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const Newticket = () =>{
  // const options = [
  //   { name: "One", id: 1 },
  //   { name: "Two", id: 2 },
  //   { name: "Three", id: 3 },
  //   { name: "four", id: 4 }
  // ];
  let decoded = jwtDecode(localStorage.getItem("token"))
     localStorage.setItem('decoded',decoded)
    console.log(decoded._id)
  const [val,setVal] =useState([])
  const [user,setUser]=useState([])
useEffect(()=>{
	axios.get("http://localhost:8080/"+decoded._id)
	.then(res=>setUser(res.data[0]))
},[])
 console.log(user.name)
  // fetch("http://localhost:8080/newticket").then(res=>res.json())
  // .then(data=>data(element => {
  //   set(element.name)
  // }));
  useEffect(()=>{
    axios.get("http://localhost:8080/newticket")
    .then(res=>setVal(res.data))
},[])

console.log(val)
  // console.log(val.at(1))
  //val.forEach((e)=>{console.log(e);})

// const display=(e)=>(
//   <option>{e}</option>
// )
  const [data, setData] = useState({ name: "", type: "" ,assignee:"",description:""});
        const handleChange = e => {
            const { name, value } = e.target;
            setData(prevState => ({
                ...prevState,
                [name]: value
            }));
            console.log(data)
        };

        const handleSubmit=(e)=> {
        e.preventDefault();
      
          // Once the form has been submitted, this function will post to the backend
       const {name, type,assignee,description}=data;
         
          const postURL = "http://localhost:8080/newticket" //Our previously set up route in the backend
          axios.post(postURL,data)
          toast("Submitted Successfully")
          // fetch(postURL, {
          //     method: 'POST',
          //     headers: {
          //         'Accept': 'application/json',
          //         'Content-Type': 'application/json',
          //     },
          //     body: JSON.stringify({ // We should keep the fields consistent for managing this data later
          //       name, type,assignee,description
          //     })
          // })
          // .then(()=>{
          //     // Once posted, the user will be notified 
          //     console.log(data);
          //     alert('You have been added to the system!');
          // })
           setTimeout(()=>{window.location.reload()},5000)  
           
      }



  return (
    <>
    <ToastContainer />
    {/* <h1 style={{backgroundColor:"#535353",padding:"10px"}}></h1> */}
    <h3 className='container' style={{color:"white",textAlign:"center",backgroundColor:"#535353",padding:"10px"}}>New Ticket</h3>
    <Container>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="form.name">
            <Form.Label style={{fontWeight:"bold"}}>Name:</Form.Label>
            <Form.Control type="text" placeholder="Enter Your name" name="name" value={data.name} autoFocus  onChange={handleChange}/>
        </Form.Group>
        <Form.Group controlId="form.type">
            <Form.Label style={{fontWeight:"bold"}}>Type:</Form.Label>
        <Form.Select aria-label="Default select example" name="type" onChange={handleChange}>
          <option>Open this select Type</option>
          <option value="IT Infra">IT Infra</option>
          <option value="Human Resources">Human Resources</option>
          <option value="IT Application">IT Application</option>
          <option value="Policy & Process">Policy & Process</option>
        </Form.Select>
        </Form.Group>
        <Form.Group controlId="form.assignee">
            <Form.Label style={{fontWeight:"bold"}}>Assignee:</Form.Label>
            <Form.Select  name="assignee" onChange={handleChange}>
              <option>Select Assignee</option>
              {val.map((e)=>(decoded._id!=e._id?<option value={e.name}>{e.name}</option>:null))}
            </Form.Select>
            {/* <select name="assignee" id="form.assignee">
            {val.map((e)=>(<option>{e.name}</option>))}
              </select> */}
        </Form.Group>
        <Form.Group controlId="form.textarea">
            <Form.Label style={{fontWeight:"bold"}}>Description:</Form.Label>
            <Form.Control as="textarea" rows={3} name="description" value={data.description} onChange={handleChange} />
        </Form.Group><br/>
              
      <button className="btn btn-primary" type='submit' style={{backgroundColor:"#535353"}}>Submit</button>
      </Form>
          
    </Container>
    </>
  );
}
export default Newticket;