import styles from "./styles.module.css";
import { Link} from 'react-router-dom';
import jwtDecode from "jwt-decode";
import { MDBCard, MDBCardBody, MDBCardTitle, MDBCardText, MDBCardImage, MDBBtn, MDBRipple } from 'mdb-react-ui-kit';
import { useEffect, useState } from "react";
import axios from "axios";


const Main = () => {
	const handleLogout = () => {
		localStorage.removeItem("token");
		window.location.reload();
	 };

	 let decoded = jwtDecode(localStorage.getItem("token"))
     localStorage.setItem('decoded',decoded)
    console.log(decoded._id)
const [user,setUser]=useState([])
useEffect(()=>{
	axios.get("http://localhost:8080/"+decoded._id)
	.then(res=>setUser(res.data[0]))
},[])
 console.log(user.name)
// const fetchUser=()=>{
// fetch("http://localhost:8080/"+decoded._id).then(res=>res.json()).then((data)=>setUser(data))
// console.log(user)
// }

// useEffect(() => {
//   let isActive = true;

//   fetch("http://localhost:8080/"+decoded._id)
//     .then((response) => response.json())
//     .then((data) => {
//       if (isActive) {
//         setUser(data);
//       }
//     })
//     .catch((error) => console.log(error.message));

//   return () => {
//     isActive = false;

//   };
// }, []);
// console.log(user)
	return (
		<div className={styles.main_container}>
			<nav className={styles.navbar}>
				<h1>Ticket Management</h1>
				<Link to={`/mytickets/`} className={styles.white_btn} style={{textDecoration:"none",textAlign:"center",color:"black"}}>
					My Tickets
				</Link>
				<Link to={`/myassignee/`}  className={styles.white_btn} style={{textDecoration:"none",textAlign:"center",color:"black"}}>
					Assigned To me
				</Link>
				<button className={styles.white_btn} onClick={handleLogout}>
					Logout
				</button>
			</nav>
			<h1 style={{textAlign: "center",fontFamily:"sans-serif"}}>Hello! {user.name}</h1>
			<h1 style={{textAlign: "center",fontFamily:"sans-serif"}}>Welcome to Ticket Management Tool!</h1>
			{/* <h1 style={{textAlign: "center",fontWeight:"bold",marginTop:"10%"}}><Link to="/newticket" className="btn btn-dark me-2">Create New Ticket</Link></h1> */}

		<MDBCard style={{ maxWidth: '22rem', margin: "0 auto"}}>
      <MDBRipple rippleColor='light' rippleTag='div' className='bg-image hover-overlay'> 
        <MDBCardImage src='https://akm-img-a-in.tosshub.com/indiatoday/images/story/202004/Emergency_helpline_number_2_0.png?d.Cdk3IlfnfcYcai_r91a0XAQCraQilJ&size=770:433' fluid alt='...' />
        <a>
          <div className='mask' style={{ backgroundColor: 'rgba(251, 251, 251, 0.15)' }}></div> 
        </a>
      </MDBRipple>
      <MDBCardBody>
        <MDBCardTitle>Ticket</MDBCardTitle>
        <MDBCardText>
          What the problems you have mention here to resolve your probblem.
        </MDBCardText>
        <Link to="/newticket"  ><MDBBtn style={{ backgroundColor: '#535353' }}>Create A New Ticket</MDBBtn></Link>
      </MDBCardBody>
    </MDBCard>
		</div>
		
	);
};

export default Main;