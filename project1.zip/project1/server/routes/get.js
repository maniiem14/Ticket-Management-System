// const express=require("express")
// const router=express.Router();
// const Ticket=require("../models/user1")



// router.get("/",async(req,res)=>{

//     const data=await Ticket.find();

//     res.json(data)

// })

// module.exports=router;